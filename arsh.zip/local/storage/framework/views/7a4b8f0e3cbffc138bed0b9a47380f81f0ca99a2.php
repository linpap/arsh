<?php $__env->startSection('title'); ?>
<?php echo e($user->name); ?> Posts
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-lg-12 col-md-6">
          

				<table class="tablesorter table" id="myTable">
					<thead>
						<th>ID <span class="pull-right fa fa-sort"></span></th>
						<th>Title <span class="pull-right fa fa-sort"></span> </th>
						<th>Categories <span class="pull-right fa fa-sort"></span></th>
						<th>User <span class="pull-right fa fa-sort"></span></th>						
						<th>Status <span class="pull-right fa fa-sort"></span></th>
						<th>Views <span class="pull-right fa fa-sort"></span></th>
						<th>Action</th>
					</thead>

					<tbody>
						<?php foreach($posts as $post): ?>
							<tr>
								<td><?php echo e($post->id); ?></td>
								<td><?php echo e($post->title); ?></td>
								<td><?php echo e($post->category->name); ?></td>
								<td><?php echo e($post->user->name); ?></td>
								<td><?php echo e($post->status); ?></td>
								<td><?php echo e($post->views); ?></td>
								<td>
									<?php if($post->status == 'approved' && Auth::user()->type=='admin'): ?>
									<a href="#" onclick="return confirm('This posts is already approved.');" class="btn btn-success" disabled="disabled">Approve</a>
									<?php elseif(Auth::user()->type == 'admin'): ?>
										<a href="<?php echo e(route('admin.posts.approve',$post->id)); ?>" onclick="return confirm('Are you sure?');" class="btn btn-success">Approve</a>
									<?php endif; ?>
									<?php if($post->status == 'suspended' && Auth::user()->type=='admin'): ?>
									<a href="<?php echo e(route('admin.posts.suspend',$post->id)); ?>" onclick="return confirm('This posts is already suspended.');" disabled="disabled" class="btn btn-primary">Suspend</a>
									<?php elseif(Auth::user()->type == 'admin'): ?>									
									<a href="<?php echo e(route('admin.posts.suspend',$post->id)); ?>" onclick="return confirm('Are you sure?');" class="btn btn-primary">Suspend</a>
									<?php endif; ?>
									<a href="<?php echo e(route('admin.posts.edit',$post->id)); ?>" class="btn btn-warning">Edit</a>
								   <a href="<?php echo e(route('admin.posts.destroy',$post->id)); ?>" onclick="return confirm('Are you sure?');" class="btn btn-danger">Delete</a> </td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<div class="text-center">
					<?php echo $posts->render(); ?>

				</div>
				
            </div>
        </div>
        <!-- /.row -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>