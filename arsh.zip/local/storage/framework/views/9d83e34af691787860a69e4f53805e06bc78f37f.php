
<?php $__env->startSection('title'); ?>
    New Subcategory
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-lg-3 col-md-6">
            	<?php echo Form::open(['route' => 'admin.subcategories.store','method' => 'POST']); ?>


            		<div class="form-group">
            			<?php echo Form::label('name','Name'); ?>

            			<?php echo Form::text('name', null,['class'=> 'form-control','placeholder'=>'Type a name for the subcategory','required']); ?>

            		</div>
                    <div class="form-group">
                        <?php echo Form::label('category_id','Select Category'); ?>

                        <?php echo Form::select('category_id',$categories,null,['class'=> 'form-control','required']); ?>

                    </div>
            		<div class="form-group">
            			<?php echo Form::submit('Add SubCategory',['class'=>'btn btn-primary']); ?>

            		</div>

            	<?php echo Form::close(); ?>

            </div>
        </div>
        <!-- /.row -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>