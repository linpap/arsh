<?php $__env->startSection('title'); ?>
    New Ebook
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-lg-6 col-md-6">           
                
                <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger" role="alert">
                    <ul>
                    <?php foreach($errors->all() as $error): ?>
                        <li><?php echo e($error); ?></li>                               
                    <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>
                <?php echo Form::open(['route' => 'admin.ebooks.store','method' => 'POST','files'=>'true','id'=>'photoPost']); ?>


                    <div class="form-group">
                        <?php echo Form::label('title','Title'); ?>

                        <?php echo Form::text('title', null,['class'=> 'form-control','placeholder'=>'Type a title','required']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('category_id','Category'); ?>

                        <?php echo Form::select('category_id', $categories,null,['class'=> ' categories form-control select-category','required']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('subcategory_id','Sub-Category'); ?>

                        <?php echo Form::select('subcategory_id', array(),null,['class'=> 'subcategories form-control',]); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('title','Wich type of Ebook you want to upload?'); ?>

                        <br>
                        <div class="btn btn-danger pdf">URL PDF</div>
                        <div class="btn btn-success normal">Normal PDF</div>
                    </div>

                    <div class="form-group ebooklink">
                        <?php echo Form::label('ebook_link','Copy and Paste Your Ebook Url'); ?>


                        
                        <?php echo Form::text('ebook_link', null,['class'=> 'form-control','placeholder'=>'Copy and Paste Your Ebook Url']); ?>

                    </div>
                    <div class="form-group ebooknormal">
                        <?php echo Form::label('ebooks','Upload your PDF FILE'); ?>


                        <?php echo Form::file('ebooks[]', array('multiple'=>true)); ?>

                        <br>
                    </div>

                    <div class="form-group">
                        <?php echo Form::label('content','Content'); ?>

                        <?php echo Form::textarea('content', null,['class' => 'textarea-content form-control','required']); ?>

                    </div>
                    
                    <?php if(Auth::user()->type == 'admin' || Auth::user()->type == 'editor'): ?>
                    <div class="form-group">
                        <?php echo Form::label('featured','Mark as Featured'); ?>                        
                        <?php echo e(Form::checkbox('featured', 'true')); ?>                         
                    </div>
                    <?php endif; ?>
                    
                    <div class="form-group">
                        <?php echo Form::label('tags','Tags'); ?>

                        <?php echo Form::text('tags',null,['class'=> 'form-control select-tag']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::submit('Add Ebook',['class'=>'btn btn-primary']); ?>

                    </div>

                <?php echo Form::close(); ?>

            </div>
        </div>
        <!-- /.row -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $('.ebooknormal').hide();
        $('.ebooklink').hide();

        $('.pdf').on('click',function(e){
            $('.ebooklink').fadeIn();
            $('.ebooknormal').hide();
        });
        $('.normal').on('click',function(e){
            $('.ebooknormal').fadeIn();
            $('.ebooklink').hide();
        });
        $('.textarea-content').trumbowyg({
            
        });
        $(".select-category").chosen({
            placeholder_text_single: "Select a category"
        });

        $('#category_id').change(function () {
            sunCategory($(this).val());
        });

        $('#photoPost').submit(function(){
            var content=$('#content').val();
            if(parseInt(content.length) < 151){
                alert("The content must be max 150 characters");
                return false;
            }
        });
            //initalize subcategories from category.
        $.ajax({
                
                url: '<?php echo e(url('admin/subcategories/getfromcategory')); ?>' + '/' + $('.categories').val(),
                type: 'GET',
                success: function(data)   {
                    $.each( data['data'], function( index, value ){                       
                    $('.subcategories').append('<option value="'+value['id']+'">'+value['name']+'</option>');
                    });
                }
        });

         $('.categories').on('change',function(){
            console.log('CATEGORY ID ' + this.value);
            $('.subcategories').html('');
            var catid = this.value;
            //search subcategories from category.
            $.ajax({
                
                url: '<?php echo e(url('admin/subcategories/getfromcategory')); ?>' + '/' + catid,
                type: 'GET',
                success: function(data)   {
                    $.each( data['data'], function( index, value ){
                        console.log(value['id']);
                    $('.subcategories').append('<option value="'+value['id']+'">'+value['name']+'</option>');
                    });
                }
            });
         });


    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>