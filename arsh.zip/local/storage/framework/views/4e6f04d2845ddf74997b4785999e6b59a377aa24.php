<?php $__env->startSection('title'); ?>
    New Photo
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-lg-6 col-md-6">           
                
                <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger" role="alert">
                    <ul>
                    <?php foreach($errors->all() as $error): ?>
                        <li><?php echo e($error); ?></li>                               
                    <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>
                <?php echo Form::open(['route' => 'admin.photos.store','method' => 'POST','files'=>'true','id'=>'photoPost']); ?>


                    <div class="form-group">
                        <?php echo Form::label('title','Title'); ?>

                        <?php echo Form::text('title', null,['class'=> 'form-control','placeholder'=>'Type a title','required']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('category_id','Category'); ?>

                        <?php echo Form::select('category_id', $categories,null,['class'=> 'form-control select-category','required']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('subcategory_id','Sub-Category'); ?>

                        <?php echo Form::select('subcategory_id', array(),null,['class'=> 'form-control','required']); ?>

                    </div>

                    <?php /*<div class="form-group">*/ ?>
                        <?php /*<?php echo Form::label('photo_link','Photo Link'); ?>*/ ?>
                        <?php /*<?php echo Form::text('photo_link', null,['class'=> 'form-control','placeholder'=>'Type photo download url','required']); ?>*/ ?>
                    <?php /*</div>*/ ?>

                    <div class="form-group">
                        <?php echo Form::label('content','Content'); ?>

                        <?php echo Form::textarea('content', null,['class' => 'textarea-content form-control', 'id'=>'content','maxlength'=>'20','minlength'=>'5','required']); ?>

                    </div>
                    <?php if(Auth::user()->type == 'admin' || Auth::user()->type == 'editor'): ?>
                    <div class="form-group">
                        <?php echo Form::label('featured','Mark as Featured'); ?>                        
                        <?php echo e(Form::checkbox('featured', 'true')); ?>                         
                    </div>
                    <?php endif; ?>
                    <div class="form-group">
                        <?php echo Form::label('tags','Tags'); ?>

                        <?php echo Form::select('tags[]', $tags,null,['class'=> 'form-control select-tag','multiple']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('images','Images'); ?>


                        <?php echo Form::file('images[]', array('multiple'=>true)); ?>

                        <div class="alert alert-warning">
                            <p>* Images must be 450px tall.</p>
                        </div>
                    </div>

                    <div class="form-group">
                        <?php echo Form::submit('Add Photo',['class'=>'btn btn-primary']); ?>

                    </div>

                <?php echo Form::close(); ?>

            </div>
        </div>
        <!-- /.row -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>

        $('#photoPost').submit(function(){
            var content=$('#content').val();
            if(parseInt(content.length) < 151){
               alert("The content must be max 150 characters");
                return false;
            }
        });

        $('.textarea-content').trumbowyg({
            
        });
        $(".select-tag").chosen({
            placeholder_text_multiple: "Select your tags"
        });
        $(".select-category").chosen({
            placeholder_text_single: "Select a category"
        });

        $('#photoPost').submit(function(){
              var content=$('#content').text();

        });

        $('#category_id').change(function () {
            sunCategory($(this).val());
        });

        var category_array=JSON.parse('<?php echo $subcategories; ?>');

        sunCategory("");

        function sunCategory(category_id) {

            if(category_id==""){
                var category_id=$('.select-category  option:first').val();
            }

            var cateArr=[];
            var html='';
            $('#subcategory_id').html("");
            for(var i=0;i<category_array.length;i++){
                if(category_array[i].category_id==category_id){
                    $('#subcategory_id').append('<option value="'+category_array[i].id+'">'+category_array[i].name+'</option>');
                }
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>