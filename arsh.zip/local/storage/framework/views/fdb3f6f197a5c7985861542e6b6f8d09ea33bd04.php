<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
          <div class="col-md-3 col-sm-6 col-xs-12">
            <?php if(session('message')): ?>
             <?php echo $__env->make(session('message'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endif; ?> 
          </div>

            <!-- /.info-box -->
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>