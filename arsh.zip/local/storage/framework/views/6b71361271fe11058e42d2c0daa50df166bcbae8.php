<?php $__env->startSection('title','All Tags'); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-lg-12 col-md-6">
            	<a href="<?php echo e(route('admin.tags.create')); ?>" class="btn btn-info"> Create New Tag</a>
            	
            	<?php echo Form::open(['route'=>'admin.tags.index','method'=>'GET','class'=>'navbar-form pull-right']); ?>

            		<div class="input-group">
            			<?php echo Form::text('name',null,['class'=>'form-control','placeholder'=>'Search Tag','aria-describedby'=>'search']); ?>

            			<span class="input-group-addon" id="search">
            				<span class="glyphicon glyphicon-search" aria-hidden="true" ></span>
            			</span>
            		</div>
            	<?php echo Form::close(); ?>

				<table class="table">
					<thead>
						<th>ID</th>
						<th>Name</th>
						<th>Action</th>
					</thead>
					<tbody>
						<?php foreach($tags as $tag): ?>
							<tr>
								<td><?php echo e($tag->id); ?></td>
								<td><?php echo e($tag->name); ?></td>
								<td><a href="<?php echo e(route('admin.tags.edit',$tag->id)); ?>" class="btn btn-warning">Edit</a> <a href="<?php echo e(route('admin.tags.destroy',$tag->id)); ?>" onclick="return confirm('Are you sure?');" class="btn btn-danger">Delete</a> </td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<?php echo $tags->render(); ?>

            </div>
        </div>
        <!-- /.row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>