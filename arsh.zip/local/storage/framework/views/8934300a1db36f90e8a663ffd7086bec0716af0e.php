<?php if(Auth::check()): ?>
  
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
        <?php if(Auth::user()->facebook_id == null && Auth::user()->twitter_id == null): ?>        
        <img src="<?php echo e(asset('img/users/profile').'/profile_'.Auth::user()->profile_image); ?>" class="img-circle" alt="The Post Page ">
        <?php elseif(Auth::user()->facebook_id != 'null' || Auth::user()->twitter_id != 'null'): ?>          
          <img src="<?php echo e(Auth::user()->profile_image); ?>" class="img-circle" alt="The Post Page ">
        <?php else: ?>
         <img src="<?php echo e(asset('img/profile.png')); ?>" class="img-circle" alt="The Post Page ">
        <?php endif; ?>
        </div>
        
        <div class="pull-left info">
          <p><?php echo e(Auth::user()->name); ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> <?php echo e(Auth::user()->tagline); ?></a>
        </div>
        s
      </div>
      <!-- search form -->
      <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form>
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="header">MAIN NAVIGATION</li>
        <li class="<?php echo e((Request::is('admin/users/'.Auth::user()->id.'/edit') ? 'active' : '')); ?>"><a href="<?php echo e(route('admin.home')); ?>"><i class="fa fa-dashboard"></i>Dashboard</a>
        </li>
        <?php if(Auth::user()->type == 'admin' || Auth::user()->type == 'editor'): ?>

        <li class="treeview <?php echo e((Request::is('admin/advs') ? 'active' : '')); ?>">
          <a href="#">
            <i class="fa fa-dashboard"></i> <span>Advertisement</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu <?php echo e((Request::is('admin/advs') ? 'active' : '')); ?>">
            <li class="<?php echo e((Request::is('admin/advs') ? 'active' : '')); ?>"><a href="<?php echo e(url('admin/advs')); ?>"><i class="fa fa-circle-o"></i>View Ads</a></li>
            <li class="<?php echo e((Request::is('admin/advs/create') ? 'active' : '')); ?>"><a href="<?php echo e(url('admin/advs/create')); ?>"><i class="fa fa-circle-o"></i> Create Ads</a></li>
          </ul>
        </li>

        <li class="treeview <?php echo e((Request::is('admin/navbars') ? 'active' : '')); ?>">
          <a href="#">
            <i class="fa fa-dashboard"></i> <span>Navbars</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu <?php echo e((Request::is('admin/navbars') ? 'active' : '')); ?>">
            <li class="<?php echo e((Request::is('admin/navbars') ? 'active' : '')); ?>"><a href="<?php echo e(url('admin/navbars')); ?>"><i class="fa fa-circle-o"></i> View Items</a></li>
            <li class="<?php echo e((Request::is('admin/navbars/create') ? 'active' : '')); ?>"><a href="<?php echo e(url('admin/navbars/create')); ?>"><i class="fa fa-circle-o"></i> Create Item</a></li>
          </ul>
        </li>

        <li class="treeview <?php echo e((Request::is('admin/sidebars') ? 'active' : '')); ?>">
          <a href="#">
            <i class="fa fa-dashboard"></i> <span>Sidebar</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu <?php echo e((Request::is('admin/sidebars') ? 'active' : '')); ?>">
            <li class="<?php echo e((Request::is('admin/sidebars') ? 'active' : '')); ?>"><a href="<?php echo e(url('admin/sidebars')); ?>"><i class="fa fa-circle-o"></i> View Items</a></li>
            <li class="<?php echo e((Request::is('admin/sidebars/create') ? 'active' : '')); ?>"><a href="<?php echo e(url('admin/sidebars/create')); ?>"><i class="fa fa-circle-o"></i> Create Item</a></li>
            <li class="<?php echo e((Request::is('admin/rightblocks') ? 'active' : '')); ?>"><a href="<?php echo e(url('admin/rightblocks')); ?>"><i class="fa fa-circle-o"></i> View Right Blocks</a></li>
          </ul>
        </li>
        <li class="treeview <?php echo e((Request::is('admin/footers') ? 'active' : '')); ?>">
          <a href="#">
            <i class="fa fa-dashboard"></i> <span>Footer</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu <?php echo e((Request::is('admin/footers') ? 'active' : '')); ?>">
            <li class="<?php echo e((Request::is('admin/footers') ? 'active' : '')); ?>"><a href="<?php echo e(url('admin/footers')); ?>"><i class="fa fa-circle-o"></i> View Items</a></li>
            <li class="<?php echo e((Request::is('admin/footers/create') ? 'active' : '')); ?>"><a href="<?php echo e(url('admin/footers/create')); ?>"><i class="fa fa-circle-o"></i> Create Item</a></li>
          </ul>
        </li>
        <li class="treeview <?php echo e((Request::is('admin/categories') ? 'active' : '')); ?>">
          <a href="#">
            <i class="fa fa-dashboard"></i> <span>Categories</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu <?php echo e((Request::is('admin/categories') ? 'active' : '')); ?>">
            <li class="<?php echo e((Request::is('admin/categories') ? 'active' : '')); ?>"><a href="<?php echo e(url('admin/categories')); ?>"><i class="fa fa-circle-o"></i> View Categories</a></li>
            <li class="<?php echo e((Request::is('admin/categories/create') ? 'active' : '')); ?>"><a href="<?php echo e(url('admin/categories/create')); ?>"><i class="fa fa-circle-o"></i> Create Category</a></li>
          </ul>
        </li>
        <li class="treeview <?php echo e((Request::is('admin/subcategories') ? 'active' : '')); ?>">
          <a href="#">
            <i class="fa fa-dashboard"></i> <span>Subcategories</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu <?php echo e((Request::is('admin/subcategories') ? 'active' : '')); ?>">
            <li class="<?php echo e((Request::is('admin/subcategories') ? 'active' : '')); ?>"><a href="<?php echo e(url('admin/subcategories')); ?>"><i class="fa fa-circle-o"></i> View Subcategories</a></li>
            <li class="<?php echo e((Request::is('admin/subcategories/create') ? 'active' : '')); ?>"><a href="<?php echo e(url('admin/subcategories/create')); ?>"><i class="fa fa-circle-o"></i> Create SubCategory</a></li>
          </ul>
        </li>
        <?php endif; ?>
        <?php if(Auth::user()->type != 'subscriber'): ?><!-- If not a subscriber show my the options -->
          <li class="treeview <?php echo e((Request::is('admin/posts') ? 'active' : '')); ?><?php echo e((Request::is('admin/posts/create') ? 'active' : '')); ?><?php echo e((Request::is('admin/posts/all') ? 'active' : '')); ?>">
            <a href="#">
              <i class="fa fa-dashboard"></i> <span>Posts</span>
              <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
              </span>
            </a>
            <ul class="treeview-menu">
              <?php if(Auth::user()->type == 'admin' || Auth::user()->type == 'editor'): ?>
              <li class="<?php echo e((Request::is('admin/all') ? 'active' : '')); ?>"><a href="<?php echo e(url('admin/posts/all')); ?>"><i class="fa fa-circle-o"></i> All posts</a></li>
              <?php endif; ?>
              <li class="<?php echo e((Request::is('admin/posts') ? 'active' : '')); ?>"><a href="<?php echo e(url('admin/posts')); ?>"><i class="fa fa-circle-o"></i> View My Posts</a></li>
              <li class="<?php echo e((Request::is('admin/posts/create') ? 'active' : '')); ?>"><a href="<?php echo e(url('admin/posts/create')); ?>"><i class="fa fa-circle-o"></i> Create Post</a></li>
            </ul>
          </li>
          
          <li class="treeview <?php echo e((Request::is('admin/photos') ? 'active' : '')); ?><?php echo e((Request::is('admin/photos/create') ? 'active' : '')); ?><?php echo e((Request::is('admin/photos/all') ? 'active' : '')); ?>">
            <a href="#">
              <i class="fa fa-photo"></i> <span>Photo Posts</span>
              <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
              </span>
            </a>
            <ul class="treeview-menu">
              <?php if(Auth::user()->type == 'admin' || Auth::user()->type == 'editor'): ?>
              <li class="<?php echo e((Request::is('admin/photos/all') ? 'active' : '')); ?>"><a href="<?php echo e(url('admin/photos/all')); ?>"><i class="fa fa-photo"></i> All Photo Posts</a></li>
              <?php endif; ?>
              <li class="<?php echo e((Request::is('admin/photos') ? 'active' : '')); ?>"><a href="<?php echo e(url('admin/photos')); ?>"><i class="fa fa-photo"></i> View My Photo Posts</a></li>
              <li class="<?php echo e((Request::is('admin/photos/create') ? 'active' : '')); ?>"><a href="<?php echo e(url('admin/photos/create')); ?>"><i class="fa fa-photo"></i> Create Photo Post</a></li>
            </ul>
          </li>
          <li class="treeview <?php echo e((Request::is('admin/videos') ? 'active' : '')); ?><?php echo e((Request::is('admin/videos/create') ? 'active' : '')); ?><?php echo e((Request::is('admin/videos/all') ? 'active' : '')); ?>">
            <a href="#">
              <i class="fa fa-video-camera"></i> <span>Video Posts</span>
              <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
              </span>
            </a>
            
            <ul class="treeview-menu">
              <?php if(Auth::user()->type == 'admin' || Auth::user()->type == 'editor'): ?>
              <li class="<?php echo e((Request::is('admin/videos/all') ? 'active' : '')); ?>"><a href="<?php echo e(url('admin/videos/all')); ?>"><i class="fa fa-circle"></i> All Video Posts</a></li>
              <?php endif; ?>
              <li class="<?php echo e((Request::is('admin/videos') ? 'active' : '')); ?>"><a href="<?php echo e(url('admin/videos')); ?>"><i class="fa fa-circle"></i> View My Video Posts</a></li>
              <li class="<?php echo e((Request::is('admin/videos/create') ? 'active' : '')); ?>"><a href="<?php echo e(url('admin/videos/create')); ?>"><i class="fa fa-photo"></i> Create Video Post</a></li>
            </ul>
          </li>
          <li class="treeview <?php echo e((Request::is('admin/ebooks') ? 'active' : '')); ?><?php echo e((Request::is('admin/ebooks/create') ? 'active' : '')); ?><?php echo e((Request::is('admin/ebooks/all') ? 'active' : '')); ?>">
            <a href="#">
              <i class="fa fa-book"></i> <span>Ebooks</span>
              <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
              </span>
            </a>
            <ul class="treeview-menu">
            <?php if(Auth::user()->type == 'admin' || Auth::user()->type == 'editor'): ?>
              <li class="<?php echo e((Request::is('admin/ebooks/all') ? 'active' : '')); ?>"><a href="<?php echo e(url('admin/ebooks/all')); ?>"><i class="fa fa-book"></i> All Ebooks</a></li>
            <?php endif; ?>
              <li class="<?php echo e((Request::is('admin/ebook') ? 'active' : '')); ?>"><a href="<?php echo e(url('admin/ebooks')); ?>"><i class="fa fa-book"></i> View My Ebooks</a></li>
              <li class="<?php echo e((Request::is('admin/ebooks/create') ? 'active' : '')); ?>"><a href="<?php echo e(url('admin/ebooks/create')); ?>"><i class="fa fa-book"></i> Create Ebook</a></li>
            </ul>
          </li>
          <?php if(Auth::user()->type == 'admin' || Auth::user()->type == 'editor'): ?>
          <li class="<?php echo e((Request::is('admin/users') ? 'active' : '')); ?>"><a href="<?php echo e(url('admin/users')); ?>"><i class="fa fa-group"></i>All Users</a>
          </li>
          <?php endif; ?>
        <?php endif; ?> <!-- If not a subscriber show my the options -->
        <li class="<?php echo e((Request::is('admin/users/'.Auth::user()->id.'/edit') ? 'active' : '')); ?>"><a href="<?php echo e(url('admin/users/'.Auth::user()->id.'/edit/')); ?>"><i class="fa fa-user"></i>Edit Profile</a>
        </li>

      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>
<?php endif; ?>