<?php $__env->startSection('title'); ?>
    Create Notification
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-lg-6 col-md-6">
  
                <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger" role="alert">
                    <ul>
                    <?php foreach($errors->all() as $error): ?>
                        <li><?php echo e($error); ?></li>                               
                    <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>
                <?php echo Form::open(['route' => ['admin.rightblocks.store'],'method' => 'POST','files'=>'true']); ?>


                    <div class="form-group">
                        <?php echo Form::label('title','Title'); ?>

                        <?php echo Form::text('title', null,['class'=> 'form-control','placeholder'=>'Type a description','required']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('description','Description'); ?>

                        <?php echo Form::text('description', null,['class'=> 'form-control','placeholder'=>'Type a description','required']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('type','Type'); ?>

                        <?php echo Form::select('type',[''=>'Select section','post_single'=> 'Post Single','ebook_single'=> 'Ebook Single','photo_single'=> 'Photo Single','video_single' => 'Video Single','video' => 'Video Page','photo' => 'Photo Page','video' => 'Video Page','ebook' => 'Ebook Page','home' => 'Home Page','archive' => 'Archive Page','category' => 'Category Page','profile' => 'Profile Page'],null,['class'=> 'form-control section','required']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::submit('Create Block',['class'=>'btn btn-primary']); ?>

                    </div>

                <?php echo Form::close(); ?>

            </div>
        </div>
        <!-- /.row -->
        </div>
        <!-- /.row -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script>
        $('.textarea-content').trumbowyg({
            
        });
        $(".select-tag").chosen({
            placeholder_text_multiple: "Select your tags"
        });
        $(".select-category").chosen({
            placeholder_text_single: "Select a category"
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>