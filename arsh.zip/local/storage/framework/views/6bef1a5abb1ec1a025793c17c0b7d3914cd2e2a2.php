<?php $__env->startSection('title','My Posts'); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-lg-12 col-md-6">
            	<a href="<?php echo e(route('admin.posts.create')); ?>" class="btn btn-info"> Create New Post</a>
            	<?php echo Form::open(['route'=>'admin.posts.index','method'=>'GET','class'=>'navbar-form pull-right']); ?>

            		<div class="input-group">
            			<?php echo Form::text('title',null,['class'=>'form-control','placeholder'=>'Search Post','aria-describedby'=>'search']); ?>

            			<span class="input-group-addon" id="search">
            				<span class="glyphicon glyphicon-search" aria-hidden="true" ></span>
            			</span>
            		</div>
            	<?php echo Form::close(); ?>

            	<hr>

				<table class="tablesorter table" id="myTable" data-count="<?php echo e(count($posts)); ?>"> <!-- Get count to validate 3 post only and don't break the front end -->
					<thead>
						<th>ID <span class="pull-right fa fa-sort"></span></th>
						<th>Title <span class="pull-right fa fa-sort"></span> </th>
						<th>Categories <span class="pull-right fa fa-sort"></span></th>
						<th>User <span class="pull-right fa fa-sort"></span></th>
						<th>Status <span class="pull-right fa fa-sort"></span></th>
						<th>Views <span class="pull-right fa fa-sort"></span></th>
						<th>Shares <span class="pull-right fa fa-sort"></span></th>
						<th>Likes <span class="pull-right fa fa-sort"></span></th>
						<th>Points <span class="pull-right fa fa-sort"></span></th>
						<th>Action</th>
					</thead>

					<tbody>
						<?php foreach($posts as $post): ?>
							<tr>
								<td><?php echo e($post->id); ?></td>
								<td><?php echo e($post->title); ?></td>
								<td><?php echo e($post->category->name); ?></td>
								<td><?php echo e($post->user->name); ?></td>
								<td><?php echo e($post->status); ?></td>
								<td><?php echo e($post->views); ?></td>
								<td><?php echo e($post->shares); ?></td>
								<td><?php echo e($post->likes); ?></td>
								<td><?php echo e($post->points); ?></td>
									<td>
										<?php if($post->status == 'approved' && Auth::user()->type=='admin' || Auth::user()->type == 'editor'): ?>
										<a href="#"  class="approve-disable btn btn-success" disabled="disabled">Approve</a>
										<?php elseif(Auth::user()->type == 'admin' || Auth::user()->type == 'editor'): ?>
										<a href="<?php echo e(route('admin.posts.approve',$post->id)); ?>"  class="approve btn btn-success">Approve</a>
										<?php endif; ?>
										<?php if($post->status == 'suspended' && Auth::user()->type=='admin' || Auth::user()->type == 'editor'): ?>
										<a href="<?php echo e(route('admin.posts.suspend',$post->id)); ?>"  disabled="disabled" class="suspend-disable btn btn-primary">Suspend</a>
										<?php elseif(Auth::user()->type == 'admin' || Auth::user()->type == 'editor'): ?>
										<?php if(Auth::user()->type != 'subscriptor'): ?>					
										<a href="<?php echo e(route('admin.posts.suspend',$post->id)); ?>" class="suspend btn btn-primary">Suspend</a>
										<?php endif; ?>
										<?php endif; ?>
										<a href="<?php echo e(route('admin.posts.edit',$post->id)); ?>" class="edit btn btn-warning">Edit</a>
										<?php if(Auth::user()->type == 'admin'): ?>
									    <a href="<?php echo e(route('admin.posts.destroy',$post->id)); ?>"  class="delete btn btn-danger">Delete</a>
									    <?php endif; ?> 
									</td>
						<?php endforeach; ?>
					</tbody>
				</table>
				<div class="text-center">
					<?php echo $posts->render(); ?>

				</div>
				
            </div>
        </div>
        <!-- /.row -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>