<?php $__env->startSection('title'); ?>
    Edit Post
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-lg-6 col-md-6">
                <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger" role="alert">
                    <ul>
                    <?php foreach($errors->all() as $error): ?>
                        <li><?php echo e($error); ?></li>                               
                    <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>
                <?php echo Form::open(['route' => ['admin.posts.update',$post->id],'method' => 'PUT','files'=>'true']); ?>


                    <div class="form-group">
                        <?php echo Form::label('title','Title'); ?>

                        <?php echo Form::text('title', $post->title,['class'=> 'form-control','placeholder'=>'Type a title','required']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('category_id','Category'); ?>

                        <?php echo Form::select('category_id', $categories,$post->category->id,['class'=> 'form-control select-category categories','required']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('subcategory_id','Sub-Category'); ?>

                        <?php echo Form::select('subcategory_id', $subcategory,null,['class'=> 'form-control subcategories']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('content','Content'); ?>

                        <?php echo Form::textarea('content', $post->content,['class' => 'textarea-content','required']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('featured_text','Featured Text'); ?>

                        <?php echo Form::textarea('featured_text', $post->featured_text,['class' => 'textarea-content form-control','required']); ?>

                    </div>
                    <?php if(Auth::user()->type == 'admin' || Auth::user()->type == 'editor'): ?>
                    <div class="form-group">
                        <?php echo Form::label('featured','Mark as Featured'); ?>

                        <?php if($post->featured == 'true'): ?>
                        <?php echo e(Form::checkbox('featured', 'true',true)); ?>

                        <?php else: ?>
                        <?php echo e(Form::checkbox('featured', 'true',false)); ?>

                        <?php endif; ?>  
                    </div>
                    <?php endif; ?>
                    
                    <div class="form-group">
                        <?php echo Form::label('tags','Tags'); ?>

                        <?php echo Form::text('tags',$myTags,['class'=> 'form-control select-tag']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('images','Images'); ?>


                        <?php echo Form::file('images[]', array('multiple'=>true)); ?>

                        <div class="alert alert-warning">
                            <p>* Images must be 450px tall.</p>
                        </div>
                    </div>
                    <div class="form-group myid" data-post="<?php echo e($post->id); ?>">
                        <?php echo Form::submit('Edit Post',['class'=>'btn btn-primary']); ?>

                    </div>

                <?php echo Form::close(); ?>

            </div>
            
            <!-- Post Images -->
            <div class="col-md-6 type" data-type="posts">
                <h1>Images</h1>
                <hr class="count" data-count="<?php echo e(count($post->images)); ?>">
                <?php if(count($post->images) > 0): ?>  
                    <?php
                        $i=0;
                    ?>
                    <?php foreach($post->images as $image): ?>
                    <div class="col-xs-12">
                        <img src="<?php echo e(asset('img/posts/thumbs').'/thumb_'.$image->name, '$post->title'); ?>" alt="The Public Post <?php echo e($post->title); ?>">
                        <p class="col-xs-12" style="padding-left:0px; margin-top:10px;">
                            <a href="#" class="btn-delete btn btn-danger"  data-imgid="<?php echo e($image->id); ?>"><i class="fa fa-trash fa-2x"></i></a>
                        </p>
                    </div>
                    <hr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>Not images found. Please add a new image.</p>  
                <?php endif; ?>       
            </div>
        </div>
        <!-- /.row -->
        </div>
        <!-- /.row -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(".select-category").chosen({
            placeholder_text_single: "Select a category"
        });
        
        $('.textarea-content').trumbowyg({
            
        });    
            //initalize subcategories from category.
        $.ajax({
                
                url: '<?php echo e(url('admin/subcategories/getfromcategory')); ?>' + '/' + $('.categories').val(),
                type: 'GET',
                success: function(data)   {
                    $.each( data['data'], function( index, value ){                       
                    $('.subcategories').append('<option value="'+value['id']+'">'+value['name']+'</option>');
                    });
                }
        });

         $('.categories').on('change',function(){
            console.log('CATEGORY ID ' + this.value);
            $('.subcategories').html('');
            var catid = this.value;
            //search subcategories from category.
            $.ajax({
                
                url: '<?php echo e(url('admin/subcategories/getfromcategory')); ?>' + '/' + catid,
                type: 'GET',
                success: function(data)   {
                    $.each( data['data'], function( index, value ){
                        console.log(value['id']);
                    $('.subcategories').append('<option value="'+value['id']+'">'+value['name']+'</option>');
                    });
                }
            });
         });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>