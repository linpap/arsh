<?php $__env->startSection('title','All PhotoPosts'); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-lg-12 col-md-6">
            	<a href="<?php echo e(route('admin.photos.create')); ?>" class="btn btn-info"> Create New Photophoto</a>
            	<?php echo Form::open(['route'=>'admin.photos.index','method'=>'GET','class'=>'navbar-form pull-right']); ?>

            		<div class="input-group">
            			<?php echo Form::text('title',null,['class'=>'form-control','placeholder'=>'Search Photophoto','aria-describedby'=>'search']); ?>

            			<span class="input-group-addon" id="search">
            				<span class="glyphicon glyphicon-search" aria-hidden="true" ></span>
            			</span>
            		</div>
            	<?php echo Form::close(); ?>

            	<hr>

				<table class="tablesorter table" id="myTable" data-count="<?php echo e(count($photos)); ?>"> <!-- Get count to validate 3 post only and don't break the front end -->
					<thead>
						<th>ID <span class="pull-right fa fa-sort"></span></th>
						<th>Title <span class="pull-right fa fa-sort"></span> </th>
						<th>Categories <span class="pull-right fa fa-sort"></span></th>
						<th>User <span class="pull-right fa fa-sort"></span></th>
						<th>Status <span class="pull-right fa fa-sort"></span></th>
						<th>Views <span class="pull-right fa fa-sort"></span></th>
						<th>Action</th>
					</thead>
					<tbody>
						<?php foreach($photos as $photo): ?>
							<tr>
								<td><?php echo e($photo->id); ?></td>
								<td><?php echo e($photo->title); ?></td>
								<td><?php echo e($photo->category->name); ?></td>
								<td><?php echo e($photo->user->name); ?></td>
								<td><?php echo e($photo->status); ?></td>
								<td><?php echo e($photo->views); ?></td>
								<td>
									<?php if($photo->status == 'approved' && Auth::user()->type=='admin' || Auth::user()->type == 'editor'): ?>
									<a href="#" onclick="return confirm('This photos is already approved.');" class="approve-disable btn btn-success" disabled="disabled">Approve</a>
									<?php elseif(Auth::user()->type == 'admin' || Auth::user()->type == 'editor'): ?>
									<a href="<?php echo e(route('admin.photos.approve',$photo->id)); ?>"  class="approve btn btn-success">Approve</a>
									<?php endif; ?>
									<?php if($photo->status == 'suspended' && Auth::user()->type=='admin' || Auth::user()->type == 'editor'): ?>
									<a href="<?php echo e(route('admin.photos.suspend',$photo->id)); ?>"  disabled="disabled" class="suspend-disable btn btn-primary">Suspend</a>
									<?php elseif(Auth::user()->type == 'admin' || Auth::user()->type == 'editor'): ?>
									<?php if(Auth::user()->type != 'subscriptor'): ?>					
									<a href="<?php echo e(route('admin.photos.suspend',$photo->id)); ?>" class="suspend btn btn-primary">Suspend</a>
									<?php endif; ?>
									<?php endif; ?>
									<a href="<?php echo e(route('admin.photos.edit',$photo->id)); ?>" class="edit btn btn-warning">Edit</a>
									<?php if(Auth::user()->type == 'admin'): ?>
								    <a href="<?php echo e(route('admin.photos.destroy',$photo->id)); ?>"  class="delete btn btn-danger">Delete</a>
								    <?php endif; ?> 
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<div class="text-center">
					<?php echo $photos->render(); ?>

				</div>
				
            </div>
        </div>
        <!-- /.row -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>