
<?php $__env->startSection('title','Footer Navbar'); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-lg-12 col-md-6">
            	<a href="<?php echo e(route('admin.footers.create')); ?>" class="btn btn-info"> Add new item</a>
            	<?php echo Form::open(['route'=>'admin.footers.index','method'=>'GET','class'=>'navbar-form pull-right']); ?>

            		<div class="input-group">
            			<?php echo Form::text('title',null,['class'=>'form-control','placeholder'=>'Search Photophoto','aria-describedby'=>'search']); ?>

            			<span class="input-group-addon" id="search">
            				<span class="glyphicon glyphicon-search" aria-hidden="true" ></span>
            			</span>
            		</div>
            	<?php echo Form::close(); ?>

            	<hr>
				<table class="tablesorter table" id="myTable" data-count="<?php echo e(count($footers)); ?>"> <!-- Get count to validate 3 post only and don't break the front end -->
					<thead>
						<th>ID <span class="pull-right fa fa-sort"></span></th>
						<th>Position <span class="pull-right fa fa-sort"></span> </th>
						<th>Category <span class="pull-right fa fa-sort"></span></th>
						<th>Action</th>
					</thead>
					<tbody>
						<?php foreach($footers as $footer): ?>
							<tr>
								<td><?php echo e($footer->id); ?></td>
								<td><?php echo e($footer->position); ?></td>
								<td><?php echo e($footer->category->name); ?></td>
								<td>
									<?php if(Auth::user()->type == 'admin' ||Auth::user()->type == 'editor'): ?>
									<a href="<?php echo e(route('admin.footers.edit',$footer->id)); ?>" class="edit btn btn-warning">Edit</a>
									<?php endif; ?>
									
									<?php if(Auth::user()->type == 'admin'): ?>
								    <a href="<?php echo e(route('admin.footers.destroy',$footer->id)); ?>"  class="delete btn btn-danger">Delete</a>
								    <?php endif; ?> 
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<div class="text-center">
					<?php echo $footers->render(); ?>

				</div>
				
            </div>
        </div>
        <!-- /.row -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>