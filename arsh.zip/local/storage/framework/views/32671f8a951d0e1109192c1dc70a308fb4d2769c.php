<?php $__env->startSection('title','All Text Blocks'); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-lg-12 col-md-6">
            	<a href="<?php echo e(route('admin.rightblocks.create')); ?>" class="btn btn-info"> Create New Block</a>
				<table class="table">
					<thead>
						<th>ID</th>
						<th>Description</th>
						<th>Type</th>
						<th>Action</th>
					</thead>
					<tbody>
						<?php foreach($rightblocks as $rightblock): ?>
							<tr>
								<td><?php echo e($rightblock->id); ?></td>
								<td><?php echo e($rightblock->description); ?></td>
								<td><?php echo e($rightblock->type); ?></td>
								<td>
									<?php if(Auth::user()->type == 'admin' || Auth::user()->type == 'editor'): ?>
									<a href="<?php echo e(route('admin.rightblocks.edit',$rightblock->id)); ?>" class="edit btn btn-warning">Edit</a>

									<?php endif; ?>
									<?php if(Auth::user()->type == 'admin'): ?>
								    <a href="<?php echo e(route('admin.rightblocks.destroy',$rightblock->id)); ?>"  class="delete btn btn-danger">Delete</a>
								    <?php endif; ?> 
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<?php echo $rightblocks->render(); ?>

            </div>
        </div>
        <!-- /.row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>