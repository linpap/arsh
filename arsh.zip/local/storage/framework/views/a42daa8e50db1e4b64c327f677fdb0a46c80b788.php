<?php $__env->startSection('title','All Subcategories'); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-lg-12 col-md-6">
            	<a href="<?php echo e(route('admin.subcategories.create')); ?>" class="btn btn-info"> Create New Category</a>
				<table class="table">
					<thead>
						<th>ID</th>
						<th>Name</th>
						<th>Category</th>
						<th>Action</th>
					</thead>
					<tbody>
						<?php foreach($subcategories as $subcategory): ?>
							<tr>
								<td><?php echo e($subcategory->id); ?></td>
								<td><?php echo e($subcategory->name); ?></td>
								<td><?php echo e($subcategory->category->name); ?></td>
								<td><a href="<?php echo e(route('admin.subcategories.edit',$subcategory->id)); ?>" class="btn btn-warning">Edit</a> <a href="<?php echo e(route('admin.subcategories.destroy',$subcategory->id)); ?>" onclick="return confirm('Are you sure?');" class="btn btn-danger">Delete</a> </td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<?php echo $subcategories->render(); ?>

            </div>
        </div>
        <!-- /.row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>