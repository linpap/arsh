<?php $__env->startSection('title'); ?>
    Edit Ebook
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-lg-6 col-md-6">
            
  
                <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger" role="alert">
                    <ul>
                    <?php foreach($errors->all() as $error): ?>
                        <li><?php echo e($error); ?></li>                               
                    <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>
                <?php echo Form::open(['route' => ['admin.ebooks.update',$ebook->id],'method' => 'PUT','files'=>'true']); ?>


                    <div class="form-group">
                        <?php echo Form::label('title','Title'); ?>

                        <?php echo Form::text('title', $ebook->title,['class'=> 'form-control','placeholder'=>'Type a title','required']); ?>

                    </div>

                    <div class="form-group">
                        <?php echo Form::label('category_id','Category'); ?>

                        <?php echo Form::select('category_id', $categories,$ebook->category->id,['class'=> 'form-control select-category categories','required']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::label('subcategory_id','Sub-Category'); ?>

                        <?php echo Form::select('subcategory_id', $subcategory,null,['class'=> 'form-control subcategories']); ?>

                    </div>
                    <?php if($ebook->ebook_link != ''): ?>
                    <div class="form-group">
                        <?php echo Form::label('ebook_link','Ebook Link'); ?>

                        <?php echo Form::text('ebook_link', $ebook->ebook_link,['class'=> 'form-control','placeholder'=>'Type ebook download url','required']); ?>

                    </div>
                    <?php endif; ?>

                    <div class="form-group">
                        <?php echo Form::label('content','Content'); ?>

                        <?php echo Form::textarea('content', $ebook->content,['class' => 'textarea-content','required']); ?>

                    </div>
                    <?php if(Auth::user()->type == 'admin' || Auth::user()->type == 'editor'): ?>
                    <div class="form-group">
                        <?php echo Form::label('featured','Mark as Featured'); ?>

                        <?php if($ebook->featured == 'true'): ?>
                        <?php echo e(Form::checkbox('featured', 'true',true)); ?>

                        <?php else: ?>
                        <?php echo e(Form::checkbox('featured', 'true',false)); ?>

                        <?php endif; ?>      
                    </div>
                    <?php endif; ?>
                    
                    <div class="form-group">
                        <?php echo Form::label('tags','Tags'); ?>

                        <?php echo Form::text('tags',$myTags,['class'=> 'form-control select-tag']); ?>

                    </div>
                    <div class="form-group">
                        <?php echo Form::submit('Edit Ebook',['class'=>'btn btn-primary']); ?>

                    </div>

                <?php echo Form::close(); ?>

            </div>
        </div>
        <!-- /.row -->
        </div>
        <!-- /.row -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script>

        $('.textarea-content').trumbowyg({
            
        });
        $(".select-category").chosen({
            placeholder_text_single: "Select a category"
        });    
            //initalize subcategories from category.
        $.ajax({
                
                url: '<?php echo e(url('admin/subcategories/getfromcategory')); ?>' + '/' + $('.categories').val(),
                type: 'GET',
                success: function(data)   {
                    $.each( data['data'], function( index, value ){                       
                    $('.subcategories').append('<option value="'+value['id']+'">'+value['name']+'</option>');
                    });
                }
        });

         $('.categories').on('change',function(){
            console.log('CATEGORY ID ' + this.value);
            $('.subcategories').html('');
            var catid = this.value;
            //search subcategories from category.
            $.ajax({
                
                url: '<?php echo e(url('admin/subcategories/getfromcategory')); ?>' + '/' + catid,
                type: 'GET',
                success: function(data)   {
                    $.each( data['data'], function( index, value ){
                        console.log(value['id']);
                    $('.subcategories').append('<option value="'+value['id']+'">'+value['name']+'</option>');
                    });
                }
            });
         });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>