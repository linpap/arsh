@extends('layouts.admin')
@section('title','Dashboard')
@section('content')
<div class="container">
  <div class="row">
          <div class="col-md-3 col-sm-6 col-xs-12">
           
          </div>

            <!-- /.info-box -->
  </div>
</div>
@endsection
